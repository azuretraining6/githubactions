#!/bin/bash

#Log into Azure
#az login

TEAM="oon"
ENVIRONEMT="dce"
LOCATION="centralus"

./prerequisite_resources.sh $TEAM $ENVIRONEMT $LOCATION