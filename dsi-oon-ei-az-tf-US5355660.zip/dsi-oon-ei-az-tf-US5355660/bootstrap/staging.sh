#!/bin/bash

#Log into Azure
#az login

TEAM="oon"
ENVIRONEMT="stag"
LOCATION="centralus"

./prerequisite_resources.sh $TEAM $ENVIRONEMT $LOCATION