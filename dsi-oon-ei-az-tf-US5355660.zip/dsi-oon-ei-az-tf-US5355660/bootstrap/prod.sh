#!/bin/bash

#Log into Azure
#az login

TEAM="oon"
ENVIRONEMT="prod"
LOCATION="centralus"

./prerequisite_resources.sh $TEAM $ENVIRONEMT $LOCATION